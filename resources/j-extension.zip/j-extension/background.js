chrome.webNavigation.onErrorOccurred.addListener((details) => {
  // Only intercept the main tab navigation, ignore broken images/iframes
  if (details.frameId !== 0) return;

  try {
    const urlObj = new URL(details.url);

    // If the path doesn't already end with .html, let's fix it
    if (!urlObj.pathname.endsWith(".html")) {
      
      // Handle trailing slash if present, otherwise just append .html
      if (urlObj.pathname.endsWith("/")) {
        urlObj.pathname = urlObj.pathname.slice(0, -1) + ".html";
      } else {
        urlObj.pathname += ".html";
      }

      // Force the tab to redirect to the new .html URL
      chrome.tabs.update(details.tabId, { url: urlObj.toString() });
    }
  } catch (e) {
    console.error("URL Parsing error: ", e);
  }
});
