chrome.webNavigation.onErrorOccurred.addListener((details) => {
  // Ignore sub-frames, ads, and background assets
  if (details.frameId !== 0) return;

  try {
    const urlObj = new URL(details.url);

    // STRICT LOCK: Only run on local files or localhost:8080
    const isFile = urlObj.protocol === 'file:';
    const isLocalhost = urlObj.protocol === 'http:' && urlObj.host === ('localhost:8080' || 'localhost:8000');

    if (!isFile && !isLocalhost) return;

    // Append .html safely
    if (!urlObj.pathname.endsWith(".html")) {
      if (urlObj.pathname.endsWith("/")) {
        urlObj.pathname = urlObj.pathname.slice(0, -1) + ".html";
      } else {
        urlObj.pathname += ".html";
      }

      chrome.tabs.update(details.tabId, { url: urlObj.toString() });
    }
  } catch (e) {
    console.error("URL Parsing error: ", e);
  }
});
