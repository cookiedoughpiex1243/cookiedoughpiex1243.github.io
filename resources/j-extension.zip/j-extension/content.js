// 1. HARD LOCK: Check the URL directly before doing anything else
const currentUrl = window.location.href;
const isFile = currentUrl.startsWith("file:///");
const isLocalhost = currentUrl.startsWith("http://localhost:8080") || currentUrl.startsWith("http://localhost:8000") ;

// If it's not our local files or local server, KILL the script instantly
if (isFile || isLocalhost) {

  // 2. Only look for errors if we are safely on local/localhost
  const errorPhrases = [
    "File may have been moved",
    "Error code: 404",
    "File not found",
	  "Nothing matches the given "
  ];

  const isErrorPage = errorPhrases.some(phrase => document.body.innerText.includes(phrase));

  if (isErrorPage) {
    // 3. Prevent infinite loops
    if (!currentUrl.includes(".html")) {
      if (currentUrl.endsWith("/")) {
        window.location.href = currentUrl.slice(0, -1) + ".html";
      } else {
        window.location.href = currentUrl + ".html";
      }
    }
  }
}
