// 1. HARD LOCK: Check the URL directly before doing anything else
const currentUrl = window.location.href;
const isReels = currentUrl.startsWith("https://www.instagram.com/reels");
const isFile = currentUrl.startsWith("file:///");
const isLocalhost = currentUrl.startsWith("http://localhost:8080") || currentUrl.startsWith("http://localhost:8000") ;

// If it's not our local files or local server, KILL the script instantly
if (isFile || isLocalhost) {

  // 2. Only look for errors if we are safely on local/localhost
  const errorPhrases = [
    "File may have been moved",
    "Error code: 404",
    "File not found",
	  "Nothing matches the given "
  ];

  const isErrorPage = errorPhrases.some(phrase => document.body.innerText.includes(phrase));

  if (isErrorPage) {
    // 3. Prevent infinite loops
    if (!currentUrl.includes(".html")) {
      if (currentUrl.endsWith("/")) {
        window.location.href = currentUrl.slice(0, -1) + ".html";
      } else {
        window.location.href = currentUrl + ".html";
      }
    }
  }
}

if (isReels) {
  window.location.replace("https://notebook.google.com");
}

// 4. Instagram is a single-page app, so clicking a reel from the home/inbox/feed
//    changes the URL via history.pushState instead of a full page load. Watch for
//    those client-side navigations and redirect whenever we land on a /reels URL.
const checkReelsUrl = () => {
  const url = window.location.href;
  if (url.startsWith("https://www.instagram.com/reels")) {
    window.location.replace("https://notebook.google.com");
  }
};

window.addEventListener("popstate", checkReelsUrl);
window.addEventListener("hashchange", checkReelsUrl);

// Fallback: poll the URL in case SPA navigations don't fire events we can catch
const reelsCheckInterval = setInterval(checkReelsUrl, 500);
checkReelsUrl();
