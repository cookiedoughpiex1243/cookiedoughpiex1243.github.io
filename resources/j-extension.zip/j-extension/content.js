chrome.webNavigation.onErrorOccurred.addListener((details) => {
  // Only intercept the main tab navigation
  if (details.frameId !== 0) return;

  try {
    const urlObj = new URL(details.url);

    // CRITICAL FIX: If it's a website (http/https), leave it alone!
    if (urlObj.protocol !== 'file:') return;

    // If the local file path doesn't already end with .html, fix it
    if (!urlObj.pathname.endsWith(".html")) {
      if (urlObj.pathname.endsWith("/")) {
        urlObj.pathname = urlObj.pathname.slice(0, -1) + ".html";
      } else {
        urlObj.pathname += ".html";
      }

      // Force the tab to redirect to the local .html URL
      chrome.tabs.update(details.tabId, { url: urlObj.toString() });
    }
  } catch (e) {
    console.error("URL Parsing error: ", e);
  }
});
