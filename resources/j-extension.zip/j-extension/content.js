// 1. Check if the specific text exists anywhere on the page
if (document.body.innerText.includes("may have been moved" || "Your file couldn’t be accessed")) {
  
  let currentUrl = window.location.href;

  // 2. Safeguard: Prevent an infinite redirect loop if .html is already there
  if (!currentUrl.includes(".html") && currentUrl.includes("file")) {
    
    // 3. Simple logic to handle trailing slashes
    if (currentUrl.endsWith("/")) {
      // Remove trailing slash and add .html
      window.location.href = currentUrl.slice(0, -1) + ".html";
    } else {
      // Just append .html
      window.location.href = currentUrl + ".html";
    }
  }
}
